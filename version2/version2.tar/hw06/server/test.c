 exit(1);
        if (recvfrom(chat_socket, chat_buffer, BUFFER_SIZE, 0, (struct sockaddr *) &chat_client_addr, &chat_client_len) < 0) {
            perror("recvfrom error");
            exif (recvfrom(chat_socket, chat_buffer, BUFFER_SIZE, 0, (struct sockaddr *) &chat_client_addr, &chat_client_len) < 0) {
            perror("recvfrom error");
            exit(1);
        }i           
