#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <sys/un.h>
#include <netinet/in.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <arpa/inet.h>

#define SOCKET_PATH "./sock_addr3"
#define BUFFER_SIZE 1024
#define SERVER_PORT 16161
#define CLIENT_PORT 1616

int main() {
    int input_socket = -1, chat_socket = -1;
    socklen_t input_client_len, chat_server_len, chat_client_len;
    struct sockaddr_un input_server_addr, input_client_addr;
    struct sockaddr_in chat_server_addr, chat_client_addr;
    char input_buffer[BUFFER_SIZE], chat_buffer[BUFFER_SIZE], buffer[BUFFER_SIZE];


    input_socket = socket(AF_UNIX, SOCK_DGRAM, 0);
    chat_socket = socket(AF_INET, SOCK_STREAM, 0);
    if (input_socket == -1) {
        perror("socket make error");
        return -1;
    }

    if (chat_socket == -1) {
        perror("socket make error");
        return -1;
    }
    
    input_server_addr.sun_family = AF_UNIX;
    strncpy(input_server_addr.sun_path, SOCKET_PATH, sizeof(input_server_addr.sun_path) - 1);
    
    memset(&chat_server_addr, 0, sizeof(chat_server_addr));
    chat_server_addr.sin_family = AF_INET;
    chat_server_addr.sin_port = htons(SERVER_PORT);
    chat_server_addr.sin_addr.s_addr = inet_addr("127.0.0.1");
           

    if (bind(input_socket, (struct sockaddr*)&input_server_addr, sizeof(struct sockaddr_un)) == -1) {
        perror("bind error");
        close(input_socket);
        return -1;
    }   

    if (connect(chat_socket, (struct sockaddr*)&chat_server_addr, sizeof(struct sockaddr_in)) == -1) {
        perror("connect error");
        close(chat_socket);
        return -1;
    }    
    
    input_client_len = sizeof(input_client_addr);
    chat_client_len = sizeof(chat_client_addr);
    chat_server_len = sizeof(chat_server_addr);
    int flags1 = fcntl(input_socket, F_GETFL, 0);
    fcntl(input_socket, F_SETFL, flags1 | O_NONBLOCK);

    int flags2 = fcntl(chat_socket, F_GETFL, 0);
    fcntl(chat_socket, F_SETFL, flags2 | O_NONBLOCK);

    while (1) {            
        memset(input_buffer, 0, sizeof(input_buffer));
        memset(chat_buffer, 0, sizeof(chat_buffer));  
        usleep(10000); //while 루프 내에서 CPU 소비를 줄이기 위해 짧은 지연을 추가              
        if (recvfrom(input_socket, input_buffer, BUFFER_SIZE, 0, (struct sockaddr *) &input_client_addr, &input_client_len) > 0) {                        
            sendto(chat_socket, input_buffer, BUFFER_SIZE, 0, (struct sockaddr *) &chat_server_addr, sizeof(chat_server_addr));
        }
    

        if (recv(chat_socket, chat_buffer, BUFFER_SIZE, 0)>0) {;
            printf("%s", chat_buffer);                        
        }
        
        if (strncmp(input_buffer, "\\quit", 5) == 0) {
            printf("Client is quit.");
            break;
        }
    }

    close(chat_socket);
    close(input_socket);
    unlink(SOCKET_PATH);

    return 0;
}


