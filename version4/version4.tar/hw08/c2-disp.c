#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <sys/un.h>

#define SOCKET_PATH "./sock_addr2"
#define BUFFER_SIZE 1024

int main() {
    int sd;
    struct sockaddr_un server_addr;
    char buffer[BUFFER_SIZE];
    
    sd = socket(AF_UNIX, SOCK_DGRAM, 0);        

    if(sd == -1) {
        perror("socket error");
    }
    
    server_addr.sun_family = AF_UNIX;
    strncpy(server_addr.sun_path, SOCKET_PATH, sizeof(server_addr.sun_path) - 1);            
        
    while (1) {        
        printf("Enter: ");
        fgets(buffer, sizeof(buffer), stdin);

         // 개행 문자를 NULL로 대체하여 정리
        buffer[strcspn(buffer, "\n")] = '\0';
        sendto(sd, buffer, strlen(buffer), 0, (struct sockaddr *)&server_addr, sizeof(server_addr));
        
        if (strncmp(buffer, "\\quit", 5) == 0) {
            printf("Client is quit.\n");
            break;
        }
        
        
    }
    
    close(sd);

    return 0;
}


