#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <arpa/inet.h>
#include <signal.h>
#include <pthread.h>
#include <sys/socket.h>
#include <sys/select.h>
#include <fcntl.h>

#define PORT 16161
#define MAX_CLIENTS 15
#define MAX_CHATROOM 3

int server_socket, nfds;
int client_sockets[15], c_num = 0;
struct sockaddr_in server_addr;
pthread_t threads[3];
struct sockaddr_in client_addr;    
char buffer[1024];
struct ChatInfo {
    int channel;
    int user_num;
    int participants[5];
    int new_users;
    int returned_users;
};

void handler(int signum) {
    printf("Start working on your message handler!\n");
    close(server_socket);
    for (int i = 0; i < MAX_CLIENTS; i++) {
        if (client_sockets[i] > 0) {
            close(client_sockets[i]);
        }
    }
    // 각 채팅방 관리 스레드를 빠르게 종료
    for (int i = 0; i < MAX_CHATROOM; i++) {
        pthread_cancel(threads[i]);
    }    

    // 생성한 스레드 join
    for (int i = 0; i < MAX_CHATROOM; i++) {
        pthread_join(threads[i], NULL);
    }

    printf("Signal handler finalization completed!\n");
    exit(EXIT_SUCCESS);
}

void *thread_func(void *chatPtr); 
int main() {

    if (signal(SIGINT, handler) == SIG_ERR) {
        perror("Signal registration failed");
        return EXIT_FAILURE;
    }         
    
    
    if ((server_socket = socket(AF_INET, SOCK_STREAM, 0)) == -1) {
        perror("Socket creation failed");
        exit(EXIT_FAILURE);
    }
    
    server_addr.sin_family = AF_INET;
    server_addr.sin_addr.s_addr = INADDR_ANY;
    server_addr.sin_port = htons(PORT);
    
    if (bind(server_socket, (struct sockaddr*)&server_addr, sizeof(server_addr)) == -1) {
        perror("Bind failed");
        close(server_socket);
        exit(EXIT_FAILURE);
    }
    
    if (listen(server_socket, MAX_CLIENTS) == -1) {
        perror("Listen failed");
        close(server_socket);
        exit(EXIT_FAILURE);
    }
    struct ChatInfo chatInfo[3];    

    for (int i = 0; i < 3; i++) {
        // 구조체 초기화
        for (int j = 0; j < 5; j++) {
            chatInfo[i].participants[j] = 0;
        }
        chatInfo[i].user_num = 0;
        chatInfo[i].new_users = 0;
        chatInfo[i].returned_users = 0;
        chatInfo[i].channel = i;
    }
    for (int i = 0;i < 3;i++) {        
        if(pthread_create(&threads[i],  NULL, thread_func, (void *)&chatInfo[i]) != 0) {
            perror("pthread error");
            exit(EXIT_FAILURE);
        }                    
    }

    int flags = fcntl(server_socket, F_GETFL, 0);
    fcntl(server_socket, F_SETFL, flags | O_NONBLOCK);

    while (1) {   
        usleep(10000);            

        for (int i = 0;i < 3;i++) { // 채팅방 나간 유저 대기열에 등록        
            if (chatInfo[i].returned_users != 0) {
                for (int k = 0;k < MAX_CLIENTS;k++) {
                    if (client_sockets[k] == 0) {                        
                        printf("[MAIN] Detecting Disconnection of User: %d\n", chatInfo[i].returned_users);
                        fflush(stdout);
                        client_sockets[k] = chatInfo[i].returned_users;
                        chatInfo[i].returned_users = 0;
                        break;
                    }
                }                
            }
        }        
        if (c_num < 15) {
            // 새로운 클라이언트 연결
            int new_client = accept(server_socket, NULL, 0);
            if (new_client > 0) {
                int client_flags = fcntl(new_client, F_GETFL, 0);
                fcntl(new_client, F_SETFL, client_flags | O_NONBLOCK);
                printf("new client connect: %d\n", new_client);
                fflush(stdout);
                client_sockets[c_num++] = new_client;
                snprintf(buffer, sizeof(buffer),
                "<MENU>\n"
                "1. View Chat Room List\n"
                "2. Join a Chat Room (Usage: 2 <Chat Room Number>)\n"
                "3. Exit the Program\n"
                "(Enter 0 to display the menu again)\n");
                send(client_sockets[c_num -1], buffer, sizeof(buffer), 0);
            }
        }
                
        for (int i = 0; i < MAX_CLIENTS; i++) {            
            if (client_sockets[i] > 0) {
                memset(buffer, 0, sizeof(buffer));
                ssize_t bytes_received = recv(client_sockets[i], buffer, sizeof(buffer), 0);
                 if(bytes_received > 0) {                                            
                    if (strncmp(buffer, "0", 1) == 0) {
                        printf("[MAIN] USER%d MESSAGE: %s\n", i, buffer);
                        fflush(stdout);
                        snprintf(buffer, sizeof(buffer),
                        "<MENU>\n"
                        "1. View Chat Room List\n"
                        "2. Join a Chat Room (Usage: 2 <Chat Room Number>)\n"
                        "3. Exit the Program\n"
                        "(Enter 0 to display the menu again)\n");
                        send(client_sockets[i], buffer, sizeof(buffer), 0);                        
                    }
                    else if (strncmp(buffer, "1", 1) == 0) {
                        printf("[MAIN] USER%d MESSAGE: %s\n", i, buffer);
                        fflush(stdout);            
                        memset(buffer, 0, sizeof(buffer));
                        int offset =0;
                        snprintf(buffer + offset, sizeof(buffer) - offset, "<ChatRoom info>\n");        
                        offset += strlen(buffer + offset);
                        for (int k = 0; k < 3; k++) {
                            snprintf(buffer + offset, sizeof(buffer) - offset, "[ID: %d] Chatroom-%d (%d/5)\n",k ,k ,chatInfo[k].user_num);
                            // Update the offset to the end of the current string
                            offset += strlen(buffer + offset);
                        }
                        send(client_sockets[i], buffer, sizeof(buffer) - 1, 0);
                    }
                    else if (strncmp(buffer, "2", 1) == 0) {
                        printf("[MAIN] USER%d MESSAGE: %s\n", i, buffer);
                        fflush(stdout);        
                        char room_num = buffer[2] - 48;
                        int offset =0;
                        if (chatInfo[room_num].user_num == 5) {
                            snprintf(buffer + offset, sizeof(buffer) - offset, "You have exceeded the maximum capacity for this chat room.");
                            send(client_sockets[i], buffer, sizeof(buffer), 0);
                            continue;
                        }                    
                        snprintf(buffer + offset, sizeof(buffer) - offset, "User %d joins Chatroom %d.\n", client_sockets[i], room_num);
                        offset += strlen(buffer + offset);                                                
                        send(client_sockets[i], buffer, sizeof(buffer), 0);
                        printf("%s", buffer);
                        chatInfo[room_num].new_users = client_sockets[i];
                        client_sockets[i] = 0;
                    }
                    else if (strncmp(buffer, "3", 1) == 0) {
                        printf("[MAIN] USER%d MESSAGE: %s\n", i, buffer);
                        fflush(stdout);
                        printf("[MAIN] Disconnecting from %d users.\n", i);
                        close(client_sockets[i]);
                        client_sockets[i] = 0;
                    }
                    else {
                        continue;
                    }
                }  
            }                       
        }
    }   

    close(server_socket);

    return 0;
}


// 각각의 채팅방 관리 thread 함수
void *thread_func(void *arg) { // ChatInfo 배열을 받았으므로 while문 돌면서 확인
    struct ChatInfo *chatPtr = (struct ChatInfo *)arg;    
    char room_buffer[1024];
    char temp_buffer[1024];    
    while(1) {        
        usleep(10000);                
        int new_users = chatPtr->new_users;    // 새로운 유저가 0이 아니면 새로운 user 등록하기
        if (new_users != 0){            
            chatPtr->participants[chatPtr->user_num] = new_users;
            chatPtr->new_users =0;
            chatPtr->user_num += 1;            
        }           
        for (int i = 0; i < 5; i++) {
            if (chatPtr->participants[i] > 0) {
                memset(room_buffer, 0, sizeof(room_buffer));
                memset(temp_buffer, 0, sizeof(temp_buffer));
                ssize_t bytes_received = recv(chatPtr->participants[i], room_buffer, sizeof(room_buffer), 0);
                if (bytes_received > 0) {
                    if (chatPtr->user_num == 1) {
                        printf("The user %d is alone, so the message is not delivered.\n", chatPtr->participants[i]);
                        fflush(stdout);
                        sprintf(temp_buffer, "The user %d is alone, so the message is not delivered.\n", chatPtr->participants[i]);
                        send(chatPtr->participants[i],temp_buffer, sizeof(temp_buffer), 0);
                    }
                    else {
                        printf("[Ch.%d] User %d message: %s\n", chatPtr->channel, chatPtr->participants[i], room_buffer);
                        for (int k = 0;k < 5;k++) {
                            if (i != k && chatPtr->participants[k] != 0) {
                                sprintf(temp_buffer, "User %d message: %s\n", chatPtr->participants[i], room_buffer);
                                send(chatPtr->participants[k],temp_buffer, sizeof(temp_buffer), 0);
                            }   
                            if (i == k && chatPtr->participants[k] != 0) {
                                sprintf(temp_buffer, "[ME]: %s\n", room_buffer);
                                send(chatPtr->participants[k],temp_buffer, sizeof(temp_buffer), 0);
                            }                                
                        }
                    }
                    if (strncmp(room_buffer, "quit", 4) == 0) {
                            printf("[Ch.%d] Removing User %d from the Chat Room.\n", chatPtr->channel, chatPtr->participants[i]);
                            chatPtr->returned_users = chatPtr->participants[i];
                            chatPtr->participants[i] = 0;
                            chatPtr->user_num -= 1;
                    }
                                        
                }
            }
        }
    }    
}
