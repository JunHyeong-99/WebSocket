#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <sys/un.h>

#define SOCKET_PATH "./sock_addr"
#define BUFFER_SIZE 1024

int main() {
    int sd;
    struct sockaddr_un server_addr;
    char buffer[BUFFER_SIZE];
    
    sd = socket(AF_UNIX, SOCK_STREAM, 0);

    if(sd == -1) {
        perror("socket error");
    }

    memset(&server_addr, 0, sizeof(struct sockaddr_un));
    server_addr.sun_family = AF_UNIX;
    strncpy(server_addr.sun_path, SOCKET_PATH, sizeof(server_addr.sun_path) - 1);
    
    if (connect(sd, (struct sockaddr*)&server_addr, sizeof(struct sockaddr_un)) == -1) {
        perror("connect error");
        close(sd);
        return -1;
    }

    printf("Connection successful\n.\n");
    
    while (1) {        
        printf("Enter the message you want to send: ");
        fgets(buffer, sizeof(buffer), stdin);
        send(sd, buffer, strlen(buffer), 0);
        
        if (strncmp(buffer, "\\quit", 5) == 0) {
            printf("Client is quit.\n");
            break;
        }
        
        ssize_t bytes_received = recv(sd, buffer, sizeof(buffer), 0);
        if (bytes_received <= 0) {
            perror("recv error");
            break;
        }

        printf("[YOU]: %.*s", (int)bytes_received, buffer);
        
        if (strncmp(buffer, "\\quit", 5) == 0) {
            printf("Server has quit.\n");
            break;
        }
    }
    
    close(sd);

    return 0;
}

