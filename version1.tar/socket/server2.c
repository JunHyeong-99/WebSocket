#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <sys/un.h>

#define SOCKET_PATH "./sock_addr"
#define BUFFER_SIZE 1024

int main() {
    int sd = -1, sd2 = -1;
    socklen_t client_len;
    struct sockaddr_un server_addr, client_addr;
    char buffer[BUFFER_SIZE];


    sd = socket(AF_UNIX, SOCK_STREAM, 0);     
    
    if (sd == -1) {
        perror("socket make error");
        return -1;
    }

    memset(&server_addr, 0, sizeof(struct sockaddr_un));
    server_addr.sun_family = AF_UNIX;
    strncpy(server_addr.sun_path, SOCKET_PATH, sizeof(server_addr.sun_path) - 1);

    if (bind(sd, (struct sockaddr*)&server_addr, sizeof(struct sockaddr_un)) == -1) {
        perror("bind error");
        close(sd);
        return -1;
    }
    
    
    if (listen(sd, 5) == -1) {
        perror("listen fail error");
        close(sd);
        return -1;
    }

    printf("Server waiting\n");

    
    client_len = sizeof(struct sockaddr_un);

    sd2 = accept(sd, (struct sockaddr*)&client_addr, &client_len);
    if (sd2 == -1) {
        perror("accept error");
        close(sd);
        return -1;
    }

    printf("Connection successful\n");

    
    while (1) {    
        ssize_t received_message = recv(sd2, buffer, sizeof(buffer), 0);
        if (received_message <= 0) {
            perror("recv error");
            break;
        }
        
        printf("[You]: %.*s", (int)received_message, buffer);
        
        if (strncmp(buffer, "\\quit", 5) == 0) {
            printf("Client has quit.\n");
            break;
        }
        
        printf("Enter the message you want to send: ");
        fgets(buffer, sizeof(buffer), stdin);
        send(sd2, buffer, strlen(buffer), 0);
        
        if (strncmp(buffer, "\\quit", 5) == 0) {
            printf("Server is quit.\n");
            break;
        }
    }

    close(sd2);
    close(sd);
    unlink(SOCKET_PATH);

    return 0;
}

