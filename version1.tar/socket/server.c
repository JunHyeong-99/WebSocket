#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <sys/un.h>

#define SOCKET_PATH "./sock_addr"
#define BUFFER_SIZE 1024

int main() {
    int sd, sd2;
    socklen_t client_len;
    struct sockaddr_un server_addr, client_addr;
    char buffer[BUFFER_SIZE];

    // 소켓 생성
    sd = socket(AF_UNIX, SOCK_STREAM, 0);
    if(sd == -1) {
        perror("socket error");
        return -1;
    }

    // 서버 주소 설정
    memset(&server_addr, 0, sizeof(struct sockaddr_un));
    server_addr.sun_family = AF_UNIX;
    strncpy(server_addr.sun_path, SOCKET_PATH, sizeof(server_addr.sun_path) - 1);

    // 소켓 bind
    if (bind(sd, (struct sockaddr*)&server_addr, sizeof(struct sockaddr_un)) == -1) {
        perror("bind fail");
        close(sd);
        exit(EXIT_FAILURE);
    }

    // 소켓 Listen
    if (listen(sd, 5) == -1) {
        perror("listen fail");
        close(sd);
        exit(EXIT_FAILURE);
    }

    printf("Server is waiting\n");

    // client의 accept
    client_len = sizeof(struct sockaddr_un);
    if ((sd2 = accept(sd, (struct sockaddr*)&client_addr, &client_len)) == -1) {
        perror("accept");
        close(sd);
        exit(EXIT_FAILURE);
    }

    printf("Connection successful\n");

    // 클라이언트가 종료 하기 전까지 무한 루프
    while (1) {
        // 클라이언트로 부터 메시지 받음
        ssize_t bytes_received = recv(sd2, buffer, sizeof(buffer), 0);
        if (bytes_received <= 0) {
            perror("recv");
            break;
        }

        // 받은 문자 출력
        printf("Client: %.*s", (int)bytes_received, buffer);

        // 클라이언트가 종료 메시지를 보냈는지 체크
        if (strncmp(buffer, "\\quit", 5) == 0) {
            printf("Client has quit.\n");
            break;
        }
                
    }
    
    close(sd2);
    close(sd);
    unlink(SOCKET_PATH);

    return 0;
}
