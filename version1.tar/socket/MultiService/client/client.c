#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <sys/un.h>

#define SOCKET_PATH "../server/sock_addr"
#define BUFFER_SIZE 1024

int main() {
    int sd;
    struct sockaddr_un server_addr;
    char buffer[BUFFER_SIZE];
    
    sd = socket(AF_UNIX, SOCK_STREAM, 0);        

    if(sd == -1) {
        perror("socket error");
    }

    memset(&server_addr, 0, sizeof(struct sockaddr_un));
    server_addr.sun_family = AF_UNIX;
    strncpy(server_addr.sun_path, SOCKET_PATH, sizeof(server_addr.sun_path) - 1);
    
    if (connect(sd, (struct sockaddr*)&server_addr, sizeof(struct sockaddr_un)) == -1) {
        perror("connect error");
        close(sd);
        return -1;
    }

    printf("Connection successful\n.\n");

    while (1) {
        ssize_t received_message = recv(sd, buffer, sizeof(buffer), 0);
        if (received_message <= 0) {
            perror("recv");
            break;
        }
        
        printf("%.*s", (int)received_message, buffer);
        
        printf("Enter: ");
        fgets(buffer, sizeof(buffer), stdin);        
        if (strncmp(buffer, "1", 1) == 0) {            
            memset(buffer, 0, BUFFER_SIZE);
            strcpy(buffer, "\\service 1");
            send(sd, buffer, strlen(buffer), 0);
            received_message = recv(sd, buffer, sizeof(buffer), 0);
            if (received_message <= 0) {
                perror("recv error");
                break;
            }                            
            printf("%.*s", (int)received_message, buffer);                            
            continue;
        }
        else if (strncmp(buffer, "2", 1) == 0) {
            int fileName;
            memset(buffer, 0, BUFFER_SIZE);
            strcpy(buffer, "\\service 2");
            send(sd, buffer, strlen(buffer), 0);
            received_message = recv(sd, buffer, sizeof(buffer), 0);
            if (received_message <= 0) {
                perror("recv error");
                break;
            }                
            printf("%.*s", (int)received_message, buffer);                
            fgets(buffer, sizeof(buffer), stdin);
            fileName = atoi(buffer);
            send(sd, buffer, strlen(buffer), 0);

            size_t file_size;
            recv(sd, &file_size, sizeof(file_size), 0);
            FILE *file;
            if(fileName == 1) {
                file = fopen("Book.txt", "wb");
            }            
            else if(fileName == 2) {
                file = fopen("Linux.png", "wb");
            }
            else {
                continue;
            }
            if (file == NULL) {
                perror("fopen");
                exit(EXIT_FAILURE);
            }

            size_t bytes_received = 0; // 현재 까지 받은 파일 크기

            while (bytes_received < file_size) {
                char buffer[BUFFER_SIZE];
                size_t chunk_size;
                if (bytes_received + 1024 > file_size) {                    
                    chunk_size = recv(sd, buffer, file_size - bytes_received, 0);                        
                }
                else {
                    chunk_size = recv(sd, buffer, sizeof(buffer), 0);                    
                }

                if (chunk_size <= 0) {
                    // 오류 또는 연결이 닫힌 경우
                    if (chunk_size == 0) {
                        printf("서버가 연결을 닫았습니다.\n");
                    } else {
                        perror("recv");
                    }
                    break;
                }

                fwrite(buffer, 1, chunk_size, file); // 받은 데이터를 파일에 쓰기
                bytes_received += chunk_size;
            }

            fclose(file);
            printf("finish file load.\n");
        }
        else if (strncmp(buffer, "3", 1) == 0) {
            memset(buffer, 0, BUFFER_SIZE);
            strcpy(buffer, "\\service 3");
            send(sd, buffer, strlen(buffer), 0);
            while(1) {
                received_message = recv(sd, buffer, sizeof(buffer), 0);
                if (received_message <= 0) {
                    perror("recv error");
                    break;
                }
                if (strncmp(buffer, "\\quit", 5) == 0) {                    
                    break;
                }
                printf("[You] %.*s", (int)received_message, buffer);
                printf("Enter message: ");
                fgets(buffer, sizeof(buffer), stdin);
                send(sd, buffer, strlen(buffer), 0);
            }
        }                
        
        if (strncmp(buffer, "\\quit", 5) == 0) {
            printf("Client is quit.\n");
            break;
        }
    }
    
    close(sd);

    return 0;
}

