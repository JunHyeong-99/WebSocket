#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <sys/un.h>
#include <time.h>

#define SOCKET_PATH "./sock_addr"
#define BUFFER_SIZE 1024


char* get_localtime ()
{
  time_t rawtime;
  struct tm * timeinfo;

  time (&rawtime);
  timeinfo = localtime (&rawtime);
  char *formatted_time = asctime(timeinfo);

  return formatted_time;
}

int main() {
    int sd = -1, sd2 = -1;
    socklen_t client_len;
    struct sockaddr_un server_addr, client_addr;
    char buffer[BUFFER_SIZE];


    sd = socket(AF_UNIX, SOCK_STREAM, 0);
    
    if (sd == -1) {
        perror("socket make error");
        return -1;
    }

    memset(&server_addr, 0, sizeof(struct sockaddr_un));
    server_addr.sun_family = AF_UNIX;
    strncpy(server_addr.sun_path, SOCKET_PATH, sizeof(server_addr.sun_path) - 1);

    if (bind(sd, (struct sockaddr*)&server_addr, sizeof(struct sockaddr_un)) == -1) {
        perror("bind error");
        close(sd);
        return -1;
    }
    
    
    if (listen(sd, 5) == -1) {
        perror("listen fail error");
        close(sd);
        return -1;
    }

    printf("Server waiting\n");

    
    client_len = sizeof(struct sockaddr_un);

    sd2 = accept(sd, (struct sockaddr*)&client_addr, &client_len);
    if (sd2 == -1) {
        perror("accept error");
        close(sd);
        return -1;
    }

    printf("Connection successful\n");

    
    while (1) {    
        sleep(3); // 동기화를 위한 설정
        memset(buffer, 0, BUFFER_SIZE);
        strcpy(buffer, "[Service List]\n1. Get Current Time\n2. Download File\n3. Echo Server\n");        
        send(sd2, buffer, strlen(buffer), 0);                
        ssize_t received_message = recv(sd2, buffer, sizeof(buffer), 0);
        if (received_message <= 0) {
            perror("recv error");
            break;
        }
        // 서비스 1 선택
        if (strncmp(buffer, "\\service 1", 10) == 0) {
            char *formatted_time = get_localtime();
            strcpy(buffer, formatted_time);
            send(sd2, buffer, strlen(buffer), 0);            
            continue;
        }

        //서비스 2 선택
        if (strncmp(buffer, "\\service 2", 10) == 0) {
            memset(buffer, 0, BUFFER_SIZE);
            strcpy(buffer, "[Available File List]\n1. Book.txt\n2. Linux.png\n3. Go back\nEnter: ");
            send(sd2, buffer, strlen(buffer), 0);

            received_message = recv(sd2, buffer, sizeof(buffer), 0);
            if (received_message <= 0) {
                perror("recv");
                break;
            }
            
            if (strncmp(buffer, "1", 1) == 0 || strncmp(buffer, "2", 1) == 0) {
                const char *file_names[] = {"Book.txt", "Linux.png"};
                FILE *file = fopen(file_names[atoi(buffer) - 1], "rb");

                if (file == NULL) {
                    perror("fopen");
                    break;
                }

                fseek(file, 0, SEEK_END);
                size_t file_size = ftell(file);
                fseek(file, 0, SEEK_SET);

                send(sd2, &file_size, sizeof(file_size), 0);

                size_t bytes_sent = 0;
                while (bytes_sent < file_size) {
                    size_t chunk_size = fread(buffer, 1, BUFFER_SIZE, file);
                    send(sd2, buffer, chunk_size, 0);
                    bytes_sent += chunk_size;
                }

                fclose(file);
            }
            else continue;            
            continue;
        }

        if (strncmp(buffer, "\\service 3", 10) == 0) {
            memset(buffer, 0, BUFFER_SIZE);
            strcpy(buffer, "[ECHO SERVER]\nEnter '\\quit' to exit.\n");
            send(sd2, buffer, strlen(buffer), 0);

            while (1) {
                received_message = recv(sd2, buffer, sizeof(buffer), 0);
                if (received_message <= 0) {
                    perror("recv");
                    break;
                }
                
                send(sd2, buffer, received_message, 0);
                
                if (strncmp(buffer, "\\quit", 5) == 0) {
                    printf("Client has quit the Echo Server.\n");
                    break;
                }
            }

            // Send [Service List] menu again
            continue;
        }                
    }

    close(sd2);
    close(sd);
    unlink(SOCKET_PATH);

    return 0;
}

