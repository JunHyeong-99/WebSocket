#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <sys/un.h>

#define SOCKET_PATH "./sock_addr"
#define BUFFER_SIZE 1024

int main() {
    int sd;
    struct sockaddr_un server_addr;
    char buffer[BUFFER_SIZE];

    // 클라이언트 소켓 생성
    sd = socket(AF_UNIX, SOCK_STREAM, 0);
    if(sd == -1) {
        perror("socket error");
        return -1;
    }

    // 서버 주소 설정
    memset(&server_addr, 0, sizeof(struct sockaddr_un));
    server_addr.sun_family = AF_UNIX;
    strncpy(server_addr.sun_path, SOCKET_PATH, sizeof(server_addr.sun_path) - 1);

    // 서버랑 connect
    if (connect(sd, (struct sockaddr*)&server_addr, sizeof(struct sockaddr_un)) == -1) {
        perror("connect error");
        close(sd);
        return -1;
    }

    printf("Connected successful.\n");

    // 메시지를 보내기 위한 루프
    while (1) {
        // 보낼 데이터 입력
        printf("Enter a message to send: ");
        fgets(buffer, sizeof(buffer), stdin);
        send(sd, buffer, strlen(buffer), 0);

        // 클라이언트의 종료 요청
        if (strncmp(buffer, "\\quit", 5) == 0) {
            printf("Client is quit.\n");
            break;
        }
                
    }

    
    close(sd);

    return 0;
}
