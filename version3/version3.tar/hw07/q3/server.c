#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <arpa/inet.h>
#include <sys/socket.h>
#include <sys/select.h>

#define PORT 8888
#define MAX_CLIENTS 3

int main() {
    int server_socket, client_sockets[MAX_CLIENTS], nfds, i;
    struct sockaddr_in server_addr;
    fd_set readfds;
    char buffer[1024];
    
    if ((server_socket = socket(AF_INET, SOCK_STREAM, 0)) == -1) {
        perror("socket error");
        return -1;
    }
    
    server_addr.sin_family = AF_INET;
    server_addr.sin_addr.s_addr = INADDR_ANY;
    server_addr.sin_port = htons(PORT);

    if (bind(server_socket, (struct sockaddr*)&server_addr, sizeof(server_addr)) == -1) {
        perror("bind error");
        close(server_socket);
        return -1;
    }
    
    if (listen(server_socket, MAX_CLIENTS) == -1) {
        perror("listen error");
        close(server_socket);
        return -1;
    }
    
    
    for (i = 0; i < MAX_CLIENTS; i++) {
        client_sockets[i] = 0;
    }

    nfds = 0;

    for (i = 0; i < MAX_CLIENTS; i++) {
        if ((client_sockets[i] = accept(server_socket, NULL, NULL)) == -1) {
            perror("accept");
            break;
        } else {
            printf("Client #%d connected.\n", i + 1);
        }
    }

    while (1) {        
        FD_ZERO(&readfds);                
        for (i = 0; i < MAX_CLIENTS; i++) {
            int sd = client_sockets[i];

            if (sd > 0) {
                FD_SET(sd, &readfds);
            }

            if (sd > nfds) {
                nfds = sd;
            }
        }
        
        if (select(nfds + 1, &readfds, NULL, NULL, NULL) < 0) {
            perror("select error");
        }
                        
        for (i = 0; i < MAX_CLIENTS; i++) {            
            if (FD_ISSET(client_sockets[i], &readfds)) {
                memset(buffer, 0, sizeof(buffer));
                ssize_t bytes_received = recv(client_sockets[i], buffer, sizeof(buffer) - 1, 0);
                if (bytes_received <= 0) {
                    printf("recv error %d", i);
                    close(client_sockets[i]);
                    client_sockets[i] = 0;
                } else {                    
                    printf("MSG from Client %d: %s", i + 1, buffer);
                    if (strncmp(buffer, "quit", 4) == 0) {
                        printf("Client %d is quit\n", i+1);
                        client_sockets[i] = 0;
                        break;
                    }                                        
                }
            }
        }
    }
    
    close(server_socket);

    return 0;
}

