#include <stdio.h>
#include <stdlib.h>
#include <signal.h>
#include <unistd.h>

void handler(int signum) {
    printf("Handler is called.\n");
    exit(EXIT_SUCCESS);
}

int main() {
    if (signal(SIGINT, handler) == SIG_ERR) {
        perror("Signal registration failed");
        return EXIT_FAILURE;
    }

    printf("Sleep begins!\n");
    sleep(1000);
    printf("Wake up!\n");
    return EXIT_SUCCESS;
}

